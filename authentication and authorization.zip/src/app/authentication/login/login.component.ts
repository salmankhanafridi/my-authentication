import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  check:any
  err:any

  constructor(public service:AuthService, public auth:AuthGuard, public router :Router) { 
    if (this.service.currentUserValue) { 
     
  }
  }
  loginForm:any;

  ngOnInit(): void {
    this.setForm();
    this.checkCheckBoxvalue(event);
   
   }

   

  setForm() {
    this.loginForm = new FormGroup({
      userName: new FormControl("", [Validators.required]),
      password: new FormControl("", [Validators.required])
    })
  }


  checkCheckBoxvalue(event:any){
    console.log(event.target.checked)
    this.check=event.target.checked
    

  }




  userLogin() {
    let username=this.loginForm.value.userName
    let password=this.loginForm.value.password
    if (this.loginForm.invalid) {
      return;
    }
    if (this.loginForm.valid) {
     
     this.service.login(username,password).subscribe(res=>{
       console.log(res);
      this.router.navigate(['dashboard'])
     
      this.auth.value.next(true)
    }) 
    }
  }



  
 
  }


  




