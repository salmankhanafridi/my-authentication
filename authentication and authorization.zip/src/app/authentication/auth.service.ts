import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, map, Observable, Subject } from 'rxjs';
import { AuthGuard } from '../core/guards/auth.guard';
import { Authresponse } from '../core/Modals/authInterface';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  private currentUserSubject: BehaviorSubject<Authresponse>;
  public currentUser: Observable<Authresponse>;

  apikey ="key=AIzaSyD37fjx_HBcEJsgq6R9-F4ECEtoRn_sDVE"

  constructor(public http:HttpClient, public router:Router,public auth:AuthGuard) {
    this.currentUserSubject = new BehaviorSubject<Authresponse>(JSON.parse(localStorage.getItem('currentUser')|| '{}'));
    this.currentUser = this.currentUserSubject.asObservable();
   }

  login(email:any,password:any):Observable<any>{
    
    return this.http.post<Authresponse>(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?${this.apikey}`,{

    email : email,
    password : password,
    returnSecureToken : true,
    }).pipe(map(user=>{
      if(user && user.idToken){

        console.log(user)
        localStorage.setItem('currentUser', JSON.stringify(user));
        this.currentUserSubject.next(user);
         
      }
    }))
      }

      public get currentUserValue(): Authresponse {
        return this.currentUserSubject.value;
    }


    

      logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.auth.value.next(true)
        this.router.navigate(['/login'])
    }
}



