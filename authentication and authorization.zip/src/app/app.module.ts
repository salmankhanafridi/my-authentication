import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

// imported modules
import {MatDividerModule} from '@angular/material/divider';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatListModule} from '@angular/material/list';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import {MatTabsModule} from '@angular/material/tabs';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';





// imported modules end

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './pages/header/header.component';
import { HomeComponent } from './pages/home/home.component';
import { SidenavComponent } from './pages/sidenav/sidenav.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LoginComponent } from './authentication/login/login.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { SettingsComponent } from './pages/settings/settings.component';
import { RootsComponent } from './pages/roots/roots.component';
import { UserSettingComponent } from './pages/user-setting/user-setting.component';
import { UserDetailComponent } from './pages/user-detail/user-detail.component';

// import { ReportsModule } from './pages/reports/Report Module/reports/reports.module';







@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    SidenavComponent,
    DashboardComponent,
    LoginComponent,
    ReportsComponent,
    SettingsComponent,
    RootsComponent,
    UserSettingComponent,
    UserDetailComponent,
    ReportsComponent,
    
    
    
    
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    BrowserAnimationsModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatTabsModule,
    ReactiveFormsModule,
    HttpClientModule
   
   

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
