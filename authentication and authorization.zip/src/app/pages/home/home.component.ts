import { Component, OnInit } from '@angular/core';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  
  sidebaropen =true;
  constructor(public auth:AuthGuard) { }

  ngOnInit(): void {

console.log( localStorage.getItem('loggedin'))


  }

  sidebartoggler(){
    this.sidebaropen =!this.sidebaropen
  }

}
