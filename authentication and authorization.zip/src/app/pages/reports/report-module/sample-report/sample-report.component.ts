import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-report',
  templateUrl: './sample-report.component.html',
  styleUrls: ['./sample-report.component.scss']
})
export class SampleReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
