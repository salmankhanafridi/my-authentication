import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportModuleRoutingModule } from './report-module-routing.module';
import { AdminReportComponent } from './admin-report/admin-report.component';
import { CustomReportComponent } from './custom-report/custom-report.component';
import { SampleReportComponent } from './sample-report/sample-report.component';

console.log('Report module loaded sucessfully')
@NgModule({
  declarations: [
    AdminReportComponent,
    CustomReportComponent,
    SampleReportComponent
  ],
  imports: [
    CommonModule,
    ReportModuleRoutingModule
  ]
})
export class ReportModuleModule { 

  constructor(){
    console.log('report component')
  }

}
