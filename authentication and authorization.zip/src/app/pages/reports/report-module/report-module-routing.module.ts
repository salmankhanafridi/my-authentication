import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminReportComponent } from './admin-report/admin-report.component';
import { CustomReportComponent } from './custom-report/custom-report.component';
import { SampleReportComponent } from './sample-report/sample-report.component';

const routes: Routes = [
 

 { path : 'admin-report' , component : AdminReportComponent},
 { path : 'custom-report' , component : CustomReportComponent},
 { path : 'sample-report' , component : SampleReportComponent},

]
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportModuleRoutingModule { }
