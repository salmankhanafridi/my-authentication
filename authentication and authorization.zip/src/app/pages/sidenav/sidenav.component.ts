import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/authentication/auth.service';
import { Authresponse } from 'src/app/core/Modals/authInterface';
import { Role } from 'src/app/core/Modals/roles';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {


   username:any
  currentUser!: Authresponse;
  menu: any[] = [
    {name: "Dashboard", maticon:"dashboard", routerlink:"dashboard"},
    {name:"User Details", maticon: "person_outline", routerlink:"userdetail"},
    {name:"Reports", maticon:"report", routerlink:"report"},
 
    
    
  ];

  admin: any[] = [
    {name: "Dashboard", maticon:"dashboard", routerlink:"dashboard"},
    {name:"User Details", maticon: "person_outline", routerlink:"userdetail"},
    {name:"Reports", maticon:"report", routerlink:"report"},
    {name: "User Setting", maticon:"settings_cell",  routerlink:"usersetting"},
    {name:"Setting", maticon:"settings",  routerlink:"setting"}
    
    
  ];
  
  constructor(private service:AuthService) { 
    
    this.service.currentUser.subscribe(x => this.currentUser = x);

    console.log(`salman check ${JSON.stringify(this.currentUser)}`)
    this.getusername();
  }

  get isAdmin() {
  
    return this.currentUser && this.currentUser.email === Role.Admin;
}



getusername(){ 
  let email=this.currentUser.email

  var username   = email.substring(0, email.lastIndexOf("@")).toUpperCase();
  this.username=username
}


  ngOnInit(): void {
  }

}
