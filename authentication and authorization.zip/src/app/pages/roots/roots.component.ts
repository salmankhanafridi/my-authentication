import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/authentication/auth.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

@Component({
  selector: 'app-roots',
  templateUrl: './roots.component.html',
  styleUrls: ['./roots.component.scss']
})
export class RootsComponent implements OnInit {
  isLogin:any


  constructor(public auth:AuthGuard,public service:AuthService,public route:Router) { 
   

    this.auth.value.subscribe(res=>{
      this.isLogin=res
    })
      if (this.service.currentUserValue.idToken) { 
      this.auth.value.next(true)
      this.route.navigate(['/dashboard'])
     
    
      }

  
    
  

  

  
  }
  ngOnInit(): void {
  
    
  }

}
