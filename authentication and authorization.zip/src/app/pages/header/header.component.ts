import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/authentication/auth.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Role } from 'src/app/core/Modals/roles';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  username:any
  currentUser:any

  menus: any[] = [
    {name: "Dashboard", maticon:"dashboard", routerlink:"dashboard"},
    {name:"User Details", maticon: "person_outline", routerlink:"userdetail"},
    {name:"Reports", maticon:"report", routerlink:"report"},
    
    
    
  ];
  admin: any[] = [
    {name: "Dashboard", maticon:"dashboard", routerlink:"dashboard"},
    {name:"User Details", maticon: "person_outline", routerlink:"userdetail"},
    {name:"Reports", maticon:"report", routerlink:"report"},
    {name: "User Setting", maticon:"settings_cell",  routerlink:"usersetting"},
    {name:"Setting", maticon:"settings",  routerlink:"setting"}
    
    
  ];
  @Output() toggleSidebarForme : EventEmitter<any>= new EventEmitter();
  constructor(public auth:AuthGuard, public router: Router, public service:AuthService) {

    this.service.currentUser.subscribe(x => this.currentUser = x);

    console.log(`salman check ${JSON.stringify(this.currentUser)}`)
    this.getusername();
   }

  ngOnInit(): void {
  }
 
  togglesidebar(){
    this.toggleSidebarForme.emit();

  }


  get isAdmin() {
  
    return this.currentUser && this.currentUser.email === Role.Admin;
}

getusername(){ 
  let email=this.currentUser.email

  var username   = email.substring(0, email.lastIndexOf("@")).toUpperCase();
  this.username=username
}

  logout(){
    var txt;
    var r = confirm("Are You want to logout!");
    if (r == true) {
      txt = "You pressed OK!";
      this.service.logout()
      this.auth.value.next(false)
    
      
    } else {
      txt = "You pressed Cancel!";
    }
   
  }
  
}
