import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './authentication/login/login.component';
import { AuthGuard } from './core/guards/auth.guard';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { HomeComponent } from './pages/home/home.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { SettingsComponent } from './pages/settings/settings.component';
import { UserDetailComponent } from './pages/user-detail/user-detail.component';
import { UserSettingComponent } from './pages/user-setting/user-setting.component';

const routes: Routes = [
  {path:'report', component:ReportsComponent},
 {path:'dashboard', component:DashboardComponent },
 {path:'home',component:HomeComponent},
 {path:'', redirectTo:'dashboard',pathMatch:'full'},
 {path:'login' , component:LoginComponent, canActivate:[AuthGuard]},
 {path:'userdetail', component:UserDetailComponent},
 {path:'report', loadChildren:()=>import('./pages/reports/report-module/report-module.module')
 .then(m=>m.ReportModuleModule) },
 {path:'usersetting', component:UserSettingComponent},
 {path:'setting', component:SettingsComponent,}

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
