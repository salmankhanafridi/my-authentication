export enum Role {
    User = 'User',
    Admin = 'admin@instapay.in'
}


let admin=['admin@instapay.in, manager@instapay.in']