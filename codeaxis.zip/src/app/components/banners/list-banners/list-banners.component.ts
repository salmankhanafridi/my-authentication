import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-banners',
  templateUrl: './list-banners.component.html',
  styleUrls: ['./list-banners.component.less']
})
export class ListBannersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
