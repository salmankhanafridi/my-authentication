import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TournmentListComponent } from './tournment-list.component';

describe('TournmentListComponent', () => {
  let component: TournmentListComponent;
  let fixture: ComponentFixture<TournmentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TournmentListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TournmentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
