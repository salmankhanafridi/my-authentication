export const environment = {
  production: true,
  apiUrl: 'http://13.127.244.3:5200/v1'
};
