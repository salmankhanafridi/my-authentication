import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  
  exclusive : any
  exclusive2 : boolean=true

  constructor(private api : ApiService) { 
    this.api.exclusive.subscribe(res=>this.exclusive=res)
    this.api.exclusive2.subscribe(res=>this.exclusive2=res)

  }

  logout(){

    window.location.reload()


  }

  ngOnInit(): void {
   
    
    
  
  }

  
  

  }



