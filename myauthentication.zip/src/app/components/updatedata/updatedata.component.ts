import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';

@Component({
  selector: 'app-updatedata',
  templateUrl: './updatedata.component.html',
  styleUrls: ['./updatedata.component.css']
})
export class UpdatedataComponent implements OnInit {
  alert: any
  disable = true
  data = {
    pincode: '',
    city: '',
    town: '',
    village: '',
    address: '',
    masjidname: '',
    halkano: '',
    zimmedar: '',
    contact: '',

  }


  create() {
    let pincode = this.data.pincode;
    let city = this.data.city;
    let town = this.data.town;
    let village = this.data.village;
    let address = this.data.village;
    let masjidname = this.data.masjidname;
    let halkano = this.data.halkano;
    let zimmedar = this.data.zimmedar;
    let contact = this.data.contact;
    this.api.updatedata(pincode, city, town, village, address, masjidname, halkano, zimmedar, contact).subscribe(res => {
      this.alert = true;
      this.disable = false;

    })

  }

  constructor(private api : ApiService) { }

  ngOnInit(): void {
  }

}
