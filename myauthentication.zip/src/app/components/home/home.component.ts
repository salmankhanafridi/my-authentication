import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { DeleteDataComponent } from '../delete-data/delete-data.component';
import { DiologeAddDataComponent } from '../diologe-add-data/diologe-add-data.component';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf'
import { UpdatedataComponent } from '../updatedata/updatedata.component';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  term: any
  createdata: any

  mosquedata: any = []

  email: any

  constructor(private api: ApiService, private route: ActivatedRoute, public diologue: MatDialog) {
    this.api.exclusive.next(true);
    this.api.exclusive2.next(false);
    this.api.guard.next(true)
     



    this.api.getdata().subscribe(res => {

      let finarr: any = []
      this.mosquedata = finarr
      // console.log(res)
      for (const element of res) {

        let model = {

          pincode: element.pincode,
          city: element.city,
          town: element.town,
          village: element.village,
          address: element.address,
          masjidname: element.masjidname,
          halkano: element.halkano,
          zimmedar: element.zimmedar,
          contact: element.contact


        }
        finarr.push(model)
        // console.log(model)

      }
    })

  }


  opendialog() {
    this.diologue.open(DiologeAddDataComponent)
    this.createdata = true
  }

  opendialogtwo() {

    this.diologue.open(DeleteDataComponent)
    this.createdata = true
  }

  opendialogthree() {

    this.diologue.open(UpdatedataComponent)
    this.createdata = true
  }

  downloadpdf() {

    let element: any = document.getElementById('table');
    html2canvas(element).then((canvas) => {
      var imagedata = canvas.toDataURL('image/png');
      let doc = new jsPDF("p", "mm", "a4")
      var imageheight = canvas.height * 208 / canvas.width
      doc.addImage(imagedata, 0, 0, 208, imageheight)
      doc.save('image.pdf');


    })
  }


  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      console.log(params.email);
      this.email = params.email
      if (this.email === 'admin@markaz.com') {
        this.createdata = true;

      }
    });
  }
}



