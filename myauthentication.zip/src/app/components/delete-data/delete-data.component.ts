import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';

@Component({
  selector: 'app-delete-data',
  templateUrl: './delete-data.component.html',
  styleUrls: ['./delete-data.component.css']
})
export class DeleteDataComponent implements OnInit {
masjidname : any
alert : any
  constructor(private api : ApiService) { }

  ngOnInit(): void {
  }


  delete(){

    this.api.deletedata(this.masjidname).subscribe(res=>console.log(res))
    this.alert=true
  }

}
