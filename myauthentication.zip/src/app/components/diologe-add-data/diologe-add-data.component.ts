import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';

@Component({
  selector: 'app-diologe-add-data',
  templateUrl: './diologe-add-data.component.html',
  styleUrls: ['./diologe-add-data.component.css']
})
export class DiologeAddDataComponent implements OnInit {
  alert: any
  disable = true
  data = {
    pincode: '',
    city: '',
    town: '',
    village: '',
    address: '',
    masjidname: '',
    halkano: '',
    zimmedar: '',
    contact: '',

  }


  create() {
    let pincode = this.data.pincode;
    let city = this.data.city;
    let town = this.data.town;
    let village = this.data.village;
    let address = this.data.village;
    let masjidname = this.data.masjidname;
    let halkano = this.data.halkano;
    let zimmedar = this.data.zimmedar;
    let contact = this.data.contact;
    this.api.createdat(pincode, city, town, village, address, masjidname, halkano, zimmedar, contact).subscribe(res => {
      this.alert = true;
      this.disable = false;

    })

  }

  constructor(private api: ApiService) { }

  ngOnInit(): void {
  }




}
