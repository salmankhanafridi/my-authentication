import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiologeAddDataComponent } from './diologe-add-data.component';

describe('DiologeAddDataComponent', () => {
  let component: DiologeAddDataComponent;
  let fixture: ComponentFixture<DiologeAddDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiologeAddDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiologeAddDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
