import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { ErrorService } from 'src/app/core/utilities/error.service';




@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  
  data={
  email : '',
  password : '',
  }

  error='' ;
  ermessage :any =this.Errmsg.errormsg

  constructor(private api :ApiService ,private Errmsg : ErrorService) { }

  ngOnInit(): void {
  }


  async onSubmit(){
    

   let email= this.data.email
   let password= this.data.password

    this.api.signup(email,password).subscribe(res=>{
   console.log(res)
}  , err=>{

  this.error= this.ermessage[err.error.error.message]
})
     
   }
  




   
  }

