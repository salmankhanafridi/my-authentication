import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { AuthGuard } from 'src/app/core/utilities/auth.guard';
import { ErrorService } from 'src/app/core/utilities/error.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  guards : any
  userdata={
    email :  '',
    password : ''
  }
  error='' ;
  ermessage :any =this.Errmsg.errormsg
  constructor(private api : ApiService, private Errmsg : ErrorService, private route : Router,private guard:AuthGuard) {

 
   }

 

  ngOnInit(): void {
   

    
  }


 
  

 
signin(){

  let email = this.userdata.email;
  let password = this.userdata.password

  this.api.login(email,password).subscribe(res=>{
     
    console.log(res)
    this.api.guard.next(true)
    
       this.route.navigate(['home'] ,{ queryParams: {email : email} });
     let storedata=  localStorage.setItem('name', JSON.stringify(email));
     console.log('local' + JSON.stringify(storedata))
      
   
    
    
      
  }, err=>{

    this.error= this.ermessage[err.error.error.message]
  }
    
  
  )
}
}
