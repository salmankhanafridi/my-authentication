import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { observable, Observable, Subject } from 'rxjs';
import { Authresponse } from 'src/app/interface/auth-interface';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  exclusive = new Subject<boolean>()
  exclusive2 = new Subject<boolean>()
  guard = new Subject<boolean>()

 
apikey ="key=AIzaSyD37fjx_HBcEJsgq6R9-F4ECEtoRn_sDVE"
 


  constructor(private http: HttpClient) { 

    
    
  }


   

   //// read data///////////////////////////////
  getdata():Observable<any>{

   return this.http.get("https://sheetdb.io/api/v1/5zy48pio1nb9a")
  }



  ////////////////readdata end get api
   
   //////  create data//////////////////////////
  createdat(pincode:string,city:any,town:any,village:any,address:any,masjidname:any,halkano:any,zimmedar:any,contact:any):Observable<any>{
  return this.http.post<any>("https://sheetdb.io/api/v1/5zy48pio1nb9a",{
   pincode: pincode,
   city   : city,
   town  : town,
   village : village,
   address : address,
   masjidname : masjidname,
   halkano : halkano,
   zimmedar : zimmedar,
   contact : contact,
 })
  }


  //////// create data end



  ///// delete data
  deletedata(masjidname:any):Observable<any>{
   return this.http.delete<any>(`https://sheetdb.io/api/v1/5zy48pio1nb9a/masjidname/${masjidname}`)
  
  }

  //////////////////deletedataend//////////



  ////////////////////////////update data

  updatedata(pincode:string,city:any,town:any,village:any,address:any,masjidname:any,halkano:any,zimmedar:any,contact:any):Observable<any>{
    return this.http.put<any>(`https://sheetdb.io/api/v1/5zy48pio1nb9a/masjidname/${masjidname}`,{
     pincode: pincode,
     city   : city,
     town  : town,
     village : village,
     address : address,
     masjidname : masjidname,
     halkano : halkano,
     zimmedar : zimmedar,
     contact : contact,
   })
    }

   



  /////////////////////////////////



 


  ////////// firwbase signup/////////////////////////////
  signup(email:any,password:any):Observable<any>{
    let headers = new HttpHeaders({ 'Access-Control-Allow-Origin': '*','content-type': 'application/json'}  )
    

    return this.http.post<Authresponse>(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?${this.apikey}`,{

    email : email,
    password : password,
    returnSecureToken : true,
    } )
  }


  //// firebase signup end///////////////////////////////////


  ////  firebase login/////////////////////////////////////
  login(email:any,password:any):Observable<any>{
    let headers = new HttpHeaders({ 'Access-Control-Allow-Origin': '*','content-type': 'application/json'}  )
    

    return this.http.post<Authresponse>(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?${this.apikey}`,{

    email : email,
    password : password,
    returnSecureToken : true,
    })
      }


      //// firebase login end///////////////////////////////////////////////////
  }

